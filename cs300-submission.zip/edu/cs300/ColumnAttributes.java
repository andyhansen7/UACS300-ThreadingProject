package edu.cs300;

/// Helper class to hold column attribute data
public class ColumnAttributes
{
    public Integer startValue;
    public Integer endValue;
    public String name;
};
