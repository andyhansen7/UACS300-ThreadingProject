//#define FILE_IN_HOME_DIR "/home/andyh/.bashrc"
#define FILE_IN_HOME_DIR "/home/arhansen/arhansen"
#define QUEUE_NUMBER 0xff
