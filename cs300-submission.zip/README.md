# UACS300-ThreadingProject

My implementation of the Java / C multi-threaded application using the System V queue. This program uses provided System V interfaces for the C application and the Java application. process_records reads reports through stdin, and replies to queries from the Java application. The Java application sends requests for data to the C application and writes the responses to output report files.

Developed by Andy Hansen, CS301-001 Fall 2021, The University of Alabama
